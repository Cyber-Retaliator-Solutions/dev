# Cyber Retaliator Solutions — Customer Solutions Portal

A modern, responsive static site ready for GitHub Pages with a custom domain **cyber.retaliator.solutions**.

## Highlights
- Dark, accessible design with high contrast
- Responsive sidebar for the Solutions catalogue
- Lightweight (HTML + CSS + vanilla JS) — no build step required
- SEO metadata + JSON‑LD Organization schema
- `CNAME` and `.nojekyll` included for Pages

## Structure
```
/
├─ index.html
├─ 404.html
├─ styles.css
├─ app.js
├─ CNAME
├─ .nojekyll
└─ assets/
   └─ logo.svg
```

## Deploy to GitHub Pages
1. Create the repository `Cyber-Retaliator-Solutions/dev` (if not already).
2. Commit the files from this package to the default branch (`main`).
3. In **Settings → Pages**, choose **Deploy from Branch**, branch `main`, folder `/root`.
4. Ensure the `CNAME` file contains: `cyber.retaliator.solutions`.
5. Point your DNS `CNAME` record for `cyber.retaliator.solutions` to `<your-github-username>.github.io.`
6. Wait for certificate to provision, then test: `https://cyber.retaliator.solutions`.

## Customize
- Replace placeholder copy in **index.html** under “Featured Solutions” with accurate product blurbs.
- Swap `/assets/logo.svg` with your brand asset (keep the filename or update the `<link rel="icon">`).
- Add product pages as new `.html` files and link them from the sidebar list.

## Accessibility & Performance
- Keyboard‑navigable sidebar (`Menu` toggles ARIA states).
- High contrast colors on dark background.
- Static assets only; ideal for CDN caching.

---
